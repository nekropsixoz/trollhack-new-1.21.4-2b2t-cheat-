package me.aidan.sydney.events.impl;

import me.aidan.sydney.events.Event;

public class ClientConnectEvent extends Event {
}
