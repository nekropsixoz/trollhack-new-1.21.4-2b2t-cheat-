package me.aidan.sydney.modules.impl.miscellaneous;

import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;

@RegisterModule(name = "AutoRespawn", description = "Makes it so that you respawn immediately after dying.", category = Module.Category.MISCELLANEOUS)
public class AutoRespawnModule extends Module {
}
