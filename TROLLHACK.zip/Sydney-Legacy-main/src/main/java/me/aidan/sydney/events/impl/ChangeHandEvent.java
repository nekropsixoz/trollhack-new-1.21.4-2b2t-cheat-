package me.aidan.sydney.events.impl;

import me.aidan.sydney.events.Event;

public class ChangeHandEvent extends Event {
}
