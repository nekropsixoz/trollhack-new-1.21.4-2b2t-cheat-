package me.aidan.sydney.modules.impl.player;

import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;

@RegisterModule(name = "MultiTask", description = "Allows you to interact with blocks while eating or using an item.", category = Module.Category.PLAYER)
public class MultiTaskModule extends Module {
}
