package me.aidan.sydney.events.impl;

import me.aidan.sydney.events.Event;

public class SendMovementEvent extends Event {
}
