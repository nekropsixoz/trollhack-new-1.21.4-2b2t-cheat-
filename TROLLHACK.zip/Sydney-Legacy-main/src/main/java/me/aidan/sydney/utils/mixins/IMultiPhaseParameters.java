package me.aidan.sydney.utils.mixins;

import net.minecraft.client.render.RenderPhase;

public interface IMultiPhaseParameters {
    RenderPhase.Target sydney$getTarget();
}
