package me.aidan.sydney.modules.impl.combat;

import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;

@RegisterModule(name = "NoHitDelay", description = "Removes the delay between multiple hits.", category = Module.Category.COMBAT)
public class NoHitDelayModule extends Module {
}
