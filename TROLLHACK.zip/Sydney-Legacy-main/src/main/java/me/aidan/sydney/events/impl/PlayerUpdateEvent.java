package me.aidan.sydney.events.impl;

import me.aidan.sydney.events.Event;

public class PlayerUpdateEvent extends Event {
    public static class Peri extends Event {}
    public static class Post extends Event {}
}
