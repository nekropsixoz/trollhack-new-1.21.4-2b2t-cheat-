package me.aidan.sydney.modules.impl.movement;

import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;

@RegisterModule(name = "AntiLevitation", description = "Prevents the levitation effect from affecting you.", category = Module.Category.MOVEMENT)
public class AntiLevitationModule extends Module {
}
