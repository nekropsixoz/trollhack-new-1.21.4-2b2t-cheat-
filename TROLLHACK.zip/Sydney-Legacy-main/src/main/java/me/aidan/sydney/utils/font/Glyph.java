package me.aidan.sydney.utils.font;

public record Glyph(GlyphMap parent, int u, int v, int width, int height, char value) {
}