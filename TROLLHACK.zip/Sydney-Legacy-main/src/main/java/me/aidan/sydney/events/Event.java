package me.aidan.sydney.events;

import lombok.Data;

@Data
public class Event {
    private boolean cancelled;
}
