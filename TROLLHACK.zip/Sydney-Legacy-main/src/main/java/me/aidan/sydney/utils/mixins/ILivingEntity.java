package me.aidan.sydney.utils.mixins;

public interface ILivingEntity {
    boolean sydney$isStaticPlayerEntity();

    void sydney$setStaticPlayerEntity(boolean staticPlayerEntity);
}
