package me.aidan.sydney.events.impl;

import me.aidan.sydney.events.Event;

public class RenderShaderEvent extends Event {
    public static class Post extends Event {}
}
