package me.aidan.sydney.modules.impl.miscellaneous;

import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;

@RegisterModule(name = "AntiPacketKick", description = "Prevents you from getting kicked by packet errors.", category = Module.Category.MISCELLANEOUS)
public class AntiPacketKickModule extends Module {
}
