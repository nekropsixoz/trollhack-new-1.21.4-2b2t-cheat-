package me.aidan.sydney.modules.impl.movement;

import me.aidan.sydney.modules.Module;
import me.aidan.sydney.modules.RegisterModule;

@RegisterModule(name = "SafeWalk", description = "Prevents you from falling off blocks.", category = Module.Category.MOVEMENT)
public class SafeWalkModule extends Module {
}
