package me.aidan.sydney.events.impl;

import me.aidan.sydney.events.Event;

public class ClientDisconnectEvent extends Event {
}
