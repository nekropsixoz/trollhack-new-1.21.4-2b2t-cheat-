package me.aidan.sydney.utils.mixins;

import net.minecraft.client.render.RenderLayer;

public interface IMultiPhase {
    RenderLayer.MultiPhaseParameters sydney$getParameters();
}
